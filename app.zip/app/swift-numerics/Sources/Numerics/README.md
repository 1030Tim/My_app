# Numerics

This umbrella module provides an easy way to get access to *all* of the Swift Numerics
API with a single import statement:
```
import Numerics
```
